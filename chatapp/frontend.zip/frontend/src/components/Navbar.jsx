import React from "react";

function Navbar(){
    return(
        <>
            <div className="navbar">
                This is navbar
            </div>
        </>
    )
}

export default Navbar;